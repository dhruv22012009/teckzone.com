<script>
  const cartItems = [];

  function addToCart(name, price) {
    cartItems.push({ name, price });
    renderCart();
  }

  function renderCart() {
    const cart = document.getElementById("cart-items");
    cart.innerHTML = "";
    if (cartItems.length === 0) {
      cart.innerHTML = "<li>Your cart is empty.</li>";
      return;
    }
    cartItems.forEach(item => {
      const li = document.createElement("li");
      li.textContent = `${item.name} - ₹${item.price.toFixed(2)}`;
      cart.appendChild(li);
    });
  }
</script>